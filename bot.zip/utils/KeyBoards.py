# from aiogram.types import KeyboardButton, ReplyKeyboardMarkup
#
#
#
# class KeyBoard():
#     def __init__(self):
#         self.show_task = KeyboardButton("Свои задачи")
#         self.profile = KeyboardButton("Профиль")
#
#         self.keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
#
